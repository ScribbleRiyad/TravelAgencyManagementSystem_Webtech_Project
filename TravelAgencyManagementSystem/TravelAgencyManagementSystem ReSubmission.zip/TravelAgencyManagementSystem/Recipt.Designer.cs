﻿
namespace TravelAgencyManagementSystem
{
    partial class Recipt
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Recipt));
            this.label8 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblYourName = new System.Windows.Forms.Label();
            this.lblYourEmail = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblYourAddress = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblYourPhoneNo = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.lblNumberOfRoom = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.lblNumberOfMember = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.lblYourNIDNumber = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.lblPaymentID = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.lblPaymentAc = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.btnSaintMartinBack = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.Color.Teal;
            this.label8.Dock = System.Windows.Forms.DockStyle.Top;
            this.label8.Font = new System.Drawing.Font("MS Reference Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label8.Location = new System.Drawing.Point(0, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(1121, 53);
            this.label8.TabIndex = 31;
            this.label8.Text = " Your Final Receipt";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.label1.Font = new System.Drawing.Font("MS Reference Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(171, 120);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(163, 29);
            this.label1.TabIndex = 32;
            this.label1.Text = " Your Name";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblYourName
            // 
            this.lblYourName.AutoSize = true;
            this.lblYourName.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.lblYourName.Font = new System.Drawing.Font("MS Reference Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblYourName.Location = new System.Drawing.Point(424, 120);
            this.lblYourName.Name = "lblYourName";
            this.lblYourName.Size = new System.Drawing.Size(222, 29);
            this.lblYourName.TabIndex = 33;
            this.lblYourName.Text = " ....................";
            // 
            // lblYourEmail
            // 
            this.lblYourEmail.AutoSize = true;
            this.lblYourEmail.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.lblYourEmail.Font = new System.Drawing.Font("MS Reference Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblYourEmail.Location = new System.Drawing.Point(424, 176);
            this.lblYourEmail.Name = "lblYourEmail";
            this.lblYourEmail.Size = new System.Drawing.Size(222, 29);
            this.lblYourEmail.TabIndex = 35;
            this.lblYourEmail.Text = " ....................";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.label4.Font = new System.Drawing.Font("MS Reference Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(174, 176);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(159, 29);
            this.label4.TabIndex = 34;
            this.label4.Text = " Your Email";
            // 
            // lblYourAddress
            // 
            this.lblYourAddress.AutoSize = true;
            this.lblYourAddress.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.lblYourAddress.Font = new System.Drawing.Font("MS Reference Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblYourAddress.Location = new System.Drawing.Point(424, 293);
            this.lblYourAddress.Name = "lblYourAddress";
            this.lblYourAddress.Size = new System.Drawing.Size(222, 29);
            this.lblYourAddress.TabIndex = 39;
            this.lblYourAddress.Text = " ....................";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.label6.Font = new System.Drawing.Font("MS Reference Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(139, 293);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(193, 29);
            this.label6.TabIndex = 38;
            this.label6.Text = " Your Address";
            // 
            // lblYourPhoneNo
            // 
            this.lblYourPhoneNo.AutoSize = true;
            this.lblYourPhoneNo.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.lblYourPhoneNo.Font = new System.Drawing.Font("MS Reference Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblYourPhoneNo.Location = new System.Drawing.Point(424, 237);
            this.lblYourPhoneNo.Name = "lblYourPhoneNo";
            this.lblYourPhoneNo.Size = new System.Drawing.Size(222, 29);
            this.lblYourPhoneNo.TabIndex = 37;
            this.lblYourPhoneNo.Text = " ....................";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.label9.Font = new System.Drawing.Font("MS Reference Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(121, 237);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(212, 29);
            this.label9.TabIndex = 36;
            this.label9.Text = " Your Phone No";
            // 
            // lblNumberOfRoom
            // 
            this.lblNumberOfRoom.AutoSize = true;
            this.lblNumberOfRoom.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.lblNumberOfRoom.Font = new System.Drawing.Font("MS Reference Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumberOfRoom.Location = new System.Drawing.Point(424, 408);
            this.lblNumberOfRoom.Name = "lblNumberOfRoom";
            this.lblNumberOfRoom.Size = new System.Drawing.Size(222, 29);
            this.lblNumberOfRoom.TabIndex = 43;
            this.lblNumberOfRoom.Text = " ....................";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.label11.Font = new System.Drawing.Font("MS Reference Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(81, 408);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(253, 29);
            this.label11.TabIndex = 42;
            this.label11.Text = " Number Of Room ";
            // 
            // lblNumberOfMember
            // 
            this.lblNumberOfMember.AutoSize = true;
            this.lblNumberOfMember.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.lblNumberOfMember.Font = new System.Drawing.Font("MS Reference Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumberOfMember.Location = new System.Drawing.Point(424, 352);
            this.lblNumberOfMember.Name = "lblNumberOfMember";
            this.lblNumberOfMember.Size = new System.Drawing.Size(222, 29);
            this.lblNumberOfMember.TabIndex = 41;
            this.lblNumberOfMember.Text = " ....................";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.label13.Font = new System.Drawing.Font("MS Reference Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(62, 352);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(272, 29);
            this.label13.TabIndex = 40;
            this.label13.Text = " Number Of Member";
            // 
            // lblYourNIDNumber
            // 
            this.lblYourNIDNumber.AutoSize = true;
            this.lblYourNIDNumber.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.lblYourNIDNumber.Font = new System.Drawing.Font("MS Reference Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblYourNIDNumber.Location = new System.Drawing.Point(424, 465);
            this.lblYourNIDNumber.Name = "lblYourNIDNumber";
            this.lblYourNIDNumber.Size = new System.Drawing.Size(222, 29);
            this.lblYourNIDNumber.TabIndex = 45;
            this.lblYourNIDNumber.Text = " ....................";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.label17.Font = new System.Drawing.Font("MS Reference Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(84, 465);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(250, 29);
            this.label17.TabIndex = 44;
            this.label17.Text = " Your NID Number";
            this.label17.Click += new System.EventHandler(this.label17_Click);
            // 
            // lblPaymentID
            // 
            this.lblPaymentID.AutoSize = true;
            this.lblPaymentID.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.lblPaymentID.Font = new System.Drawing.Font("MS Reference Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPaymentID.Location = new System.Drawing.Point(424, 598);
            this.lblPaymentID.Name = "lblPaymentID";
            this.lblPaymentID.Size = new System.Drawing.Size(222, 29);
            this.lblPaymentID.TabIndex = 51;
            this.lblPaymentID.Text = " ....................";
            this.lblPaymentID.Click += new System.EventHandler(this.label18_Click);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.label19.Font = new System.Drawing.Font("MS Reference Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(3, 598);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(331, 29);
            this.label19.TabIndex = 50;
            this.label19.Text = " Payment Transaction ID";
            // 
            // lblPaymentAc
            // 
            this.lblPaymentAc.AutoSize = true;
            this.lblPaymentAc.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.lblPaymentAc.Font = new System.Drawing.Font("MS Reference Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPaymentAc.Location = new System.Drawing.Point(424, 534);
            this.lblPaymentAc.Name = "lblPaymentAc";
            this.lblPaymentAc.Size = new System.Drawing.Size(222, 29);
            this.lblPaymentAc.TabIndex = 49;
            this.lblPaymentAc.Text = " ....................";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.label21.Font = new System.Drawing.Font("MS Reference Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(148, 534);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(184, 29);
            this.label21.TabIndex = 48;
            this.label21.Text = " Payment A/c";
            // 
            // btnSaintMartinBack
            // 
            this.btnSaintMartinBack.BackColor = System.Drawing.Color.Red;
            this.btnSaintMartinBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaintMartinBack.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnSaintMartinBack.Location = new System.Drawing.Point(941, 654);
            this.btnSaintMartinBack.Name = "btnSaintMartinBack";
            this.btnSaintMartinBack.Size = new System.Drawing.Size(136, 44);
            this.btnSaintMartinBack.TabIndex = 52;
            this.btnSaintMartinBack.Text = "Exit";
            this.btnSaintMartinBack.UseVisualStyleBackColor = false;
            this.btnSaintMartinBack.Click += new System.EventHandler(this.btnSaintMartinBack_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Teal;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.button1.Location = new System.Drawing.Point(751, 654);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(136, 44);
            this.button1.TabIndex = 53;
            this.button1.Text = "Save Info";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Recipt
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1121, 722);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnSaintMartinBack);
            this.Controls.Add(this.lblPaymentID);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.lblPaymentAc);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.lblYourNIDNumber);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.lblNumberOfRoom);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.lblNumberOfMember);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.lblYourAddress);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.lblYourPhoneNo);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.lblYourEmail);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lblYourName);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label8);
            this.Name = "Recipt";
            this.Text = "Recipt";
            this.Load += new System.EventHandler(this.Recipt_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblYourName;
        private System.Windows.Forms.Label lblYourEmail;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblYourAddress;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblYourPhoneNo;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lblNumberOfRoom;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label lblNumberOfMember;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label lblYourNIDNumber;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label lblPaymentID;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label lblPaymentAc;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Button btnSaintMartinBack;
        private System.Windows.Forms.Button button1;
    }
}