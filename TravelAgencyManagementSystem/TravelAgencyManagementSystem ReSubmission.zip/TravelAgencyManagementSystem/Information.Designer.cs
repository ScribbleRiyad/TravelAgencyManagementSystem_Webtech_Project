﻿
namespace TravelAgencyManagementSystem
{
    partial class Information
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSignUp2 = new System.Windows.Forms.Button();
            this.txtNIDnumber = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtfPhoneNumber = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtfEmail = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtfName = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnSaintMartinBack = new System.Windows.Forms.Button();
            this.txtMemberNo = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btnSignUp2
            // 
            this.btnSignUp2.BackColor = System.Drawing.Color.Teal;
            this.btnSignUp2.Font = new System.Drawing.Font("Arial", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSignUp2.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnSignUp2.Location = new System.Drawing.Point(815, 662);
            this.btnSignUp2.Name = "btnSignUp2";
            this.btnSignUp2.Size = new System.Drawing.Size(97, 44);
            this.btnSignUp2.TabIndex = 25;
            this.btnSignUp2.Text = "Next";
            this.btnSignUp2.UseVisualStyleBackColor = false;
            this.btnSignUp2.Click += new System.EventHandler(this.btnSignUp2_Click);
            // 
            // txtNIDnumber
            // 
            this.txtNIDnumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNIDnumber.Location = new System.Drawing.Point(298, 437);
            this.txtNIDnumber.Name = "txtNIDnumber";
            this.txtNIDnumber.Size = new System.Drawing.Size(350, 30);
            this.txtNIDnumber.TabIndex = 24;
            this.txtNIDnumber.TextChanged += new System.EventHandler(this.txtNIDnumber_TextChanged);
            this.txtNIDnumber.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNIDnumber_KeyPress);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.label7.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(112, 437);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(155, 28);
            this.label7.TabIndex = 23;
            this.label7.Text = "NID Number";
            // 
            // txtAddress
            // 
            this.txtAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAddress.Location = new System.Drawing.Point(298, 367);
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(350, 30);
            this.txtAddress.TabIndex = 22;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.label6.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(157, 367);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(110, 28);
            this.label6.TabIndex = 21;
            this.label6.Text = "Address";
            // 
            // txtfPhoneNumber
            // 
            this.txtfPhoneNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtfPhoneNumber.Location = new System.Drawing.Point(298, 306);
            this.txtfPhoneNumber.Name = "txtfPhoneNumber";
            this.txtfPhoneNumber.Size = new System.Drawing.Size(350, 30);
            this.txtfPhoneNumber.TabIndex = 20;
            this.txtfPhoneNumber.TextChanged += new System.EventHandler(this.txtfPhoneNumber_TextChanged);
            this.txtfPhoneNumber.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtfPhoneNumber_KeyPress);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.label5.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(84, 306);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(183, 28);
            this.label5.TabIndex = 19;
            this.label5.Text = "Phone Number";
            // 
            // txtfEmail
            // 
            this.txtfEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtfEmail.Location = new System.Drawing.Point(298, 241);
            this.txtfEmail.Name = "txtfEmail";
            this.txtfEmail.Size = new System.Drawing.Size(350, 30);
            this.txtfEmail.TabIndex = 18;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.label4.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(190, 243);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(77, 28);
            this.label4.TabIndex = 17;
            this.label4.Text = "Email";
            // 
            // txtfName
            // 
            this.txtfName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtfName.Location = new System.Drawing.Point(298, 174);
            this.txtfName.Name = "txtfName";
            this.txtfName.Size = new System.Drawing.Size(350, 30);
            this.txtfName.TabIndex = 16;
            this.txtfName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtfName_KeyPress);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.label3.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(141, 174);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(133, 28);
            this.label3.TabIndex = 15;
            this.label3.Text = " Full Name";
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Teal;
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(934, 65);
            this.label1.TabIndex = 14;
            this.label1.Text = "Tourist Information Form";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnSaintMartinBack
            // 
            this.btnSaintMartinBack.BackColor = System.Drawing.Color.Red;
            this.btnSaintMartinBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaintMartinBack.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnSaintMartinBack.Location = new System.Drawing.Point(23, 649);
            this.btnSaintMartinBack.Name = "btnSaintMartinBack";
            this.btnSaintMartinBack.Size = new System.Drawing.Size(106, 40);
            this.btnSaintMartinBack.TabIndex = 26;
            this.btnSaintMartinBack.Text = "Back";
            this.btnSaintMartinBack.UseVisualStyleBackColor = false;
            this.btnSaintMartinBack.Click += new System.EventHandler(this.btnSaintMartinBack_Click);
            // 
            // txtMemberNo
            // 
            this.txtMemberNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMemberNo.Location = new System.Drawing.Point(298, 501);
            this.txtMemberNo.Name = "txtMemberNo";
            this.txtMemberNo.Size = new System.Drawing.Size(350, 30);
            this.txtMemberNo.TabIndex = 28;
            this.txtMemberNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtMemberNo_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.label2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(122, 501);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(145, 28);
            this.label2.TabIndex = 27;
            this.label2.Text = "Member No";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.label8.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(95, 121);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(179, 28);
            this.label8.TabIndex = 30;
            this.label8.Text = " Tour Package";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // listBox1
            // 
            this.listBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 25;
            this.listBox1.Items.AddRange(new object[] {
            "Select Tour Package",
            "Cox\'s Bazar ",
            "Sajek",
            "Saint Martin"});
            this.listBox1.Location = new System.Drawing.Point(298, 121);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(350, 29);
            this.listBox1.TabIndex = 31;
            // 
            // Information
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(934, 718);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtMemberNo);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnSaintMartinBack);
            this.Controls.Add(this.btnSignUp2);
            this.Controls.Add(this.txtNIDnumber);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtAddress);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtfPhoneNumber);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtfEmail);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtfName);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Name = "Information";
            this.Text = "Information";
            this.Load += new System.EventHandler(this.Information_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSignUp2;
        private System.Windows.Forms.TextBox txtNIDnumber;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtfPhoneNumber;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtfEmail;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtfName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnSaintMartinBack;
        private System.Windows.Forms.TextBox txtMemberNo;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ListBox listBox1;
    }
}